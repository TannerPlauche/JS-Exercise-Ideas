var app = anguar.module("etsyApp", ["ngRoute"]);


app.controller("decorController", ["$scope", "$http", function ($scope, $http) {


}]);
//End of controller//////////