var app = angular.module("etsyApp");

app.service("decorService", ["$http", function ($http) {


}]);